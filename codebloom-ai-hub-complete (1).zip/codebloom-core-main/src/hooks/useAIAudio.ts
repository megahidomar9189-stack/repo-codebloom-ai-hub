import { useState, useCallback, useRef } from 'react';

export interface Transcription {
  id: string;
  text: string;
  timestamp: Date;
}

interface UseAIAudioOptions {
  model?: string;
}

export function useAIAudio(options: UseAIAudioOptions = {}) {
  const [transcriptions, setTranscriptions] = useState<Transcription[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.start(1000);
      setIsRecording(true);
      setError(null);
    } catch (err) {
      setError('Failed to access microphone. Please grant permission.');
      console.error('Recording error:', err);
    }
  }, []);

  const stopRecording = useCallback(async () => {
    return new Promise<Blob | null>((resolve) => {
      if (!mediaRecorderRef.current || mediaRecorderRef.current.state === 'inactive') {
        resolve(null);
        return;
      }

      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        mediaRecorderRef.current?.stream.getTracks().forEach(track => track.stop());
        setIsRecording(false);
        resolve(blob);
      };

      mediaRecorderRef.current.stop();
    });
  }, []);

  const transcribe = useCallback(async (audioBlob: Blob, model?: string) => {
    setIsLoading(true);
    setError(null);

    try {
      const selectedModel = model || options.model || 'whisper-large-v3';
      
      const formData = new FormData();
      formData.append('audio', audioBlob, 'audio.webm');
      formData.append('model', selectedModel);

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-audio`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: formData,
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to transcribe audio');
      }

      const data = await response.json();
      
      const newTranscription: Transcription = {
        id: crypto.randomUUID(),
        text: data.transcription || 'No transcription available',
        timestamp: new Date(),
      };

      setTranscriptions(prev => [newTranscription, ...prev]);
      return newTranscription;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An error occurred';
      setError(errorMessage);
      console.error('Transcription error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [options.model]);

  const recordAndTranscribe = useCallback(async (model?: string) => {
    const audioBlob = await stopRecording();
    if (audioBlob) {
      return transcribe(audioBlob, model);
    }
    return null;
  }, [stopRecording, transcribe]);

  const clearTranscriptions = useCallback(() => {
    setTranscriptions([]);
    setError(null);
  }, []);

  return {
    transcriptions,
    isLoading,
    isRecording,
    error,
    startRecording,
    stopRecording,
    transcribe,
    recordAndTranscribe,
    clearTranscriptions,
  };
}
