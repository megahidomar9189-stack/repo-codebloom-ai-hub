import { useState, useCallback } from 'react';

export interface GeneratedImage {
  id: string;
  prompt: string;
  imageUrl: string;
  timestamp: Date;
  model?: string;
  size?: string;
  quality?: string;
}

interface UseAIImageOptions {
  model?: string;
}

interface GenerateImageParams {
  prompt: string;
  model?: string;
  referenceImages?: string[];
  style?: string;
  size?: string;
  quality?: string;
  referenceSimilarity?: number; // 0-100
}

export function useAIImage(options: UseAIImageOptions = {}) {
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateImage = useCallback(async (params: GenerateImageParams | string) => {
    const { 
      prompt, 
      model, 
      referenceImages, 
      style,
      size,
      quality,
      referenceSimilarity,
    } = typeof params === 'string' 
      ? { prompt: params, model: undefined, referenceImages: undefined, style: undefined, size: undefined, quality: undefined, referenceSimilarity: undefined }
      : params;

    const selectedModel = model || options.model || 'stable-diffusion-xl';
    
    setIsLoading(true);
    setError(null);

    try {
      // Use Python backend for image generation
      const backendUrl = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';
      
      const response = await fetch(
        `${backendUrl}/api/generate-image`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            prompt, 
            model: selectedModel,
            style,
            size,
            quality,
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate image');
      }

      const data = await response.json();
      
      if (!data.imageUrl) {
        throw new Error('No image generated');
      }

      const newImage: GeneratedImage = {
        id: crypto.randomUUID(),
        prompt,
        imageUrl: data.imageUrl,
        timestamp: new Date(),
        model: data.model,
        size,
        quality,
      };

      setImages(prev => [newImage, ...prev]);
      return newImage;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An error occurred';
      setError(errorMessage);
      console.error('AI Image error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [options.model]);

  const clearImages = useCallback(() => {
    setImages([]);
    setError(null);
  }, []);

  return {
    images,
    isLoading,
    error,
    generateImage,
    clearImages,
  };
}
