import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface GeneratedVideo {
  id: string;
  prompt: string;
  videoUrl?: string;
  taskId?: string;
  status: 'generating' | 'processing' | 'completed' | 'error';
  timestamp: Date;
  model?: string;
  error?: string;
}

interface GenerateVideoParams {
  prompt: string;
  model?: string;
  duration?: number;
  aspectRatio?: string;
}

export function useAIVideo() {
  const [videos, setVideos] = useState<GeneratedVideo[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateVideo = useCallback(async (params: GenerateVideoParams) => {
    setIsLoading(true);
    setError(null);

    const videoId = crypto.randomUUID();
    const newVideo: GeneratedVideo = {
      id: videoId,
      prompt: params.prompt,
      status: 'generating',
      timestamp: new Date(),
      model: params.model || 'veo3',
    };

    setVideos(prev => [newVideo, ...prev]);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('ai-video', {
        body: {
          prompt: params.prompt,
          model: params.model || 'veo3',
          duration: params.duration || 5,
          aspectRatio: params.aspectRatio || '16:9',
        },
      });

      if (fnError) throw fnError;

      if (data.error) {
        throw new Error(data.error);
      }

      if (data.videoUrl) {
        // Video is ready immediately
        setVideos(prev =>
          prev.map(v =>
            v.id === videoId
              ? { ...v, videoUrl: data.videoUrl, status: 'completed' as const }
              : v
          )
        );
      } else if (data.taskId) {
        // Video is being processed, need to poll for status
        setVideos(prev =>
          prev.map(v =>
            v.id === videoId
              ? { ...v, taskId: data.taskId, status: 'processing' as const }
              : v
          )
        );
        
        // Start polling for status
        pollForCompletion(videoId, data.taskId);
      }

      return data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to generate video';
      setError(errorMessage);
      setVideos(prev =>
        prev.map(v =>
          v.id === videoId
            ? { ...v, status: 'error' as const, error: errorMessage }
            : v
        )
      );
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const pollForCompletion = useCallback(async (videoId: string, taskId: string) => {
    const maxAttempts = 60; // 5 minutes with 5 second intervals
    let attempts = 0;

    const poll = async () => {
      attempts++;
      
      try {
        const { data, error: fnError } = await supabase.functions.invoke('ai-video', {
          body: { action: 'status', taskId },
        });

        if (fnError) throw fnError;

        if (data.status === 'completed' && data.videoUrl) {
          setVideos(prev =>
            prev.map(v =>
              v.id === videoId
                ? { ...v, videoUrl: data.videoUrl, status: 'completed' as const }
                : v
            )
          );
          return;
        }

        if (data.status === 'failed' || data.error) {
          setVideos(prev =>
            prev.map(v =>
              v.id === videoId
                ? { ...v, status: 'error' as const, error: data.error || 'Generation failed' }
                : v
            )
          );
          return;
        }

        if (attempts < maxAttempts) {
          setTimeout(poll, 5000); // Poll every 5 seconds
        } else {
          setVideos(prev =>
            prev.map(v =>
              v.id === videoId
                ? { ...v, status: 'error' as const, error: 'Timeout waiting for video' }
                : v
            )
          );
        }
      } catch (err) {
        console.error('Poll error:', err);
        if (attempts < maxAttempts) {
          setTimeout(poll, 5000);
        }
      }
    };

    setTimeout(poll, 5000); // Start polling after 5 seconds
  }, []);

  const clearVideos = useCallback(() => {
    setVideos([]);
    setError(null);
  }, []);

  return {
    videos,
    isLoading,
    error,
    generateVideo,
    clearVideos,
  };
}
