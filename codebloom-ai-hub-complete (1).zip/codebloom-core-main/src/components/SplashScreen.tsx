import { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [isAnimating, setIsAnimating] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAnimating(false);
      setTimeout(onComplete, 500);
    }, 2000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div
      className={cn(
        "fixed inset-0 z-50 flex flex-col items-center justify-center bg-background transition-opacity duration-500",
        !isAnimating && "opacity-0 pointer-events-none"
      )}
    >
      <div className="relative flex flex-col items-center">
        {/* Logo with animation */}
        <div className="animate-logo-bounce">
          <div className="w-24 h-24 rounded-2xl bg-black flex items-center justify-center shadow-2xl animate-logo-glow">
            <img
              src="/logo.png"
              alt="CtrlZ Logo"
              className="w-20 h-20 object-contain"
            />
          </div>
        </div>

        {/* Text */}
        <h1 className="mt-6 text-3xl font-bold text-foreground animate-fade-in-up">
          CtrlZ
        </h1>
        <p className="mt-2 text-sm text-muted-foreground animate-fade-in-up-delayed">
          Developed by Omar Megahid
        </p>
      </div>
    </div>
  );
}
