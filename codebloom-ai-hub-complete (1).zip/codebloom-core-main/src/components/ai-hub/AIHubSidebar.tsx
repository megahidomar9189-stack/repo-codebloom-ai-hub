import { MessageSquare, Image, Mic, Video, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export type AITab = 'text' | 'image' | 'audio' | 'video';

interface AIHubSidebarProps {
  activeTab: AITab;
  onTabChange: (tab: AITab) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const tabs = [
  { id: 'text' as AITab, label: 'Text AI', icon: MessageSquare, description: 'Chat & generate text' },
  { id: 'image' as AITab, label: 'Image AI', icon: Image, description: 'Generate images' },
  { id: 'audio' as AITab, label: 'Audio AI', icon: Mic, description: 'Transcribe audio' },
  { id: 'video' as AITab, label: 'Video AI', icon: Video, description: 'Analyze videos' },
];

export function AIHubSidebar({ activeTab, onTabChange, isCollapsed, onToggleCollapse }: AIHubSidebarProps) {
  return (
    <aside className={cn(
      "flex flex-col h-full bg-sidebar border-r border-sidebar-border transition-all duration-300",
      isCollapsed ? "w-16" : "w-64"
    )}>
      {/* Logo */}
      <div className="p-4 border-b border-sidebar-border">
        <div className={cn(
          "flex items-center gap-3",
          isCollapsed && "justify-center"
        )}>
          <div className="w-10 h-10 rounded-xl bg-black flex items-center justify-center flex-shrink-0">
            <img 
              src="/logo.png" 
              alt="CtrlZ Logo" 
              className="w-8 h-8 object-contain"
            />
          </div>
          {!isCollapsed && (
            <div>
              <h1 className="font-bold text-sidebar-foreground text-lg">CtrlZ</h1>
              <p className="text-xs text-muted-foreground">Developed by Omar Megahid</p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200",
              activeTab === tab.id
                ? "bg-sidebar-accent text-sidebar-accent-foreground ai-glow-sm"
                : "text-sidebar-foreground hover:bg-sidebar-accent/50",
              isCollapsed && "justify-center px-2"
            )}
          >
            <tab.icon className={cn(
              "h-5 w-5 flex-shrink-0",
              activeTab === tab.id && "text-primary"
            )} />
            {!isCollapsed && (
              <div className="text-left">
                <div className="font-medium text-sm">{tab.label}</div>
                <div className="text-xs text-muted-foreground">{tab.description}</div>
              </div>
            )}
          </button>
        ))}
      </nav>

      {/* Collapse Toggle */}
      <div className="p-3 border-t border-sidebar-border">
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleCollapse}
          className={cn(
            "w-full",
            isCollapsed && "justify-center"
          )}
        >
          {isCollapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <>
              <ChevronLeft className="h-4 w-4 mr-2" />
              Collapse
            </>
          )}
        </Button>
      </div>
    </aside>
  );
}
