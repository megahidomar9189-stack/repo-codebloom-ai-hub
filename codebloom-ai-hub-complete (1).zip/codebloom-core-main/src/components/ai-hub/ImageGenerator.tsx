import { useState, useRef } from 'react';
import { ImageIcon, Loader2, Download, Trash2, Sparkles, Upload, X, Palette, Maximize, Gauge, Link2, ChevronDown, Wand2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { ModelSelector } from './ModelSelector';
import { useAIImage, GeneratedImage } from '@/hooks/useAIImage';
import { imageModels, imageSizeOptions, imageQualityOptions } from '@/lib/ai-models';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

const styleOptions = [
  { id: 'default', name: 'Default' },
  { id: 'photorealistic', name: 'Photorealistic' },
  { id: 'artistic', name: 'Artistic' },
  { id: 'anime', name: 'Anime' },
  { id: '3d', name: '3D Render' },
  { id: 'minimalist', name: 'Minimalist' },
];

export function ImageGenerator() {
  const [prompt, setPrompt] = useState('');
  const [selectedModel, setSelectedModel] = useState(imageModels[0].id);
  const [selectedStyle, setSelectedStyle] = useState('default');
  const [selectedSize, setSelectedSize] = useState('1024x1024');
  const [selectedQuality, setSelectedQuality] = useState('high');
  const [referenceSimilarity, setReferenceSimilarity] = useState(50);
  const [referenceImages, setReferenceImages] = useState<string[]>([]);
  const [isReferenceOpen, setIsReferenceOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { images, isLoading, error, generateImage, clearImages } = useAIImage();

  const currentModel = imageModels.find(m => m.id === selectedModel);
  const supportsReferences = currentModel?.supportsReferences ?? false;

  const handleAddReference = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newImages: string[] = [];
    
    for (let i = 0; i < Math.min(files.length, 5 - referenceImages.length); i++) {
      const file = files[i];
      if (!file.type.startsWith('image/')) continue;
      
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve) => {
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
      newImages.push(base64);
    }

    setReferenceImages(prev => [...prev, ...newImages].slice(0, 5));
    if (fileInputRef.current) fileInputRef.current.value = '';
    setIsReferenceOpen(true);
  };

  const removeReference = (index: number) => {
    setReferenceImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleGenerate = async () => {
    if (!prompt.trim() || isLoading) return;
    
    const result = await generateImage({
      prompt: prompt.trim(),
      model: selectedModel,
      referenceImages: referenceImages.length > 0 ? referenceImages : undefined,
      style: selectedStyle !== 'default' ? selectedStyle : undefined,
      size: selectedSize,
      quality: selectedQuality,
      referenceSimilarity: referenceImages.length > 0 ? referenceSimilarity : undefined,
    });
    
    if (result) {
      toast.success('Image generated successfully!');
      setPrompt('');
    } else if (error) {
      toast.error(error);
    }
  };

  const downloadImage = (image: GeneratedImage) => {
    const link = document.createElement('a');
    link.href = image.imageUrl;
    link.download = `ai-image-${image.id}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Image downloaded!');
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header - Model & Settings */}
      <div className="p-4 border-b border-border space-y-3">
        {/* Row 1: Model selector and clear */}
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <ModelSelector
            models={imageModels}
            selectedModel={selectedModel}
            onSelect={setSelectedModel}
          />
          <Button
            variant="ghost"
            size="sm"
            onClick={clearImages}
            disabled={images.length === 0}
            className="text-muted-foreground hover:text-destructive"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Clear
          </Button>
        </div>

        {/* Row 2: Size, Quality, Style */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Size */}
          <Select value={selectedSize} onValueChange={setSelectedSize}>
            <SelectTrigger className="w-[150px]">
              <Maximize className="h-4 w-4 mr-2 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {imageSizeOptions.map((size) => (
                <SelectItem key={size.id} value={size.id}>
                  <span className="flex items-center gap-2">
                    <span>{size.name}</span>
                    <span className="text-xs text-muted-foreground">{size.description}</span>
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Quality */}
          <Select value={selectedQuality} onValueChange={setSelectedQuality}>
            <SelectTrigger className="w-[130px]">
              <Gauge className="h-4 w-4 mr-2 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {imageQualityOptions.map((q) => (
                <SelectItem key={q.id} value={q.id}>
                  <span className="flex items-center gap-2">
                    <span>{q.name}</span>
                    <span className="text-xs text-muted-foreground">{q.description}</span>
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Style */}
          <Select value={selectedStyle} onValueChange={setSelectedStyle}>
            <SelectTrigger className="w-[140px]">
              <Palette className="h-4 w-4 mr-2 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {styleOptions.map((style) => (
                <SelectItem key={style.id} value={style.id}>
                  {style.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin">
        {images.length === 0 && !isLoading ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="ai-gradient w-16 h-16 rounded-2xl flex items-center justify-center mb-4">
              <ImageIcon className="h-8 w-8 text-primary-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Generate images with AI</h3>
            <p className="text-muted-foreground max-w-sm">
              Describe what you want to create. Add reference images for better results.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {isLoading && (
              <div className="ai-card flex flex-col items-center justify-center min-h-[300px]">
                <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
                <p className="text-muted-foreground">Generating your image...</p>
              </div>
            )}
            {images.map((image) => (
              <ImageCard 
                key={image.id} 
                image={image} 
                onDownload={() => downloadImage(image)}
                onEnhance={generateImage}
                isLoading={isLoading}
              />
            ))}
          </div>
        )}
      </div>

      {/* Input */}
      <div className="p-4 border-t border-border">
        <div className="space-y-3">
          {/* Reference Images Panel - Collapsible */}
          {supportsReferences && (
            <Collapsible open={isReferenceOpen} onOpenChange={setIsReferenceOpen}>
              <CollapsibleTrigger asChild>
                <button className={cn(
                  "w-full flex items-center justify-between p-3 rounded-lg border transition-all duration-300",
                  referenceImages.length > 0 
                    ? "bg-primary/10 border-primary/30 hover:bg-primary/15" 
                    : "bg-muted/30 border-border hover:bg-muted/50"
                )}>
                  <div className="flex items-center gap-2">
                    <Link2 className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">
                      صور مرجعية {referenceImages.length > 0 && `(${referenceImages.length})`}
                    </span>
                    
                    {/* Collapsed preview - show mini thumbnails when closed */}
                    {!isReferenceOpen && referenceImages.length > 0 && (
                      <div className="flex -space-x-2 ml-2 animate-fade-in">
                        {referenceImages.slice(0, 3).map((img, index) => (
                          <img
                            key={index}
                            src={img}
                            alt={`Ref ${index + 1}`}
                            className="w-8 h-8 rounded-full object-cover border-2 border-background shadow-md transition-transform hover:scale-110 hover:z-10"
                            style={{ 
                              animationDelay: `${index * 50}ms`,
                              transform: `translateY(0)`,
                            }}
                          />
                        ))}
                        {referenceImages.length > 3 && (
                          <div className="w-8 h-8 rounded-full bg-primary/20 border-2 border-background flex items-center justify-center text-xs font-medium text-primary shadow-md">
                            +{referenceImages.length - 3}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  <ChevronDown className={cn(
                    "h-4 w-4 text-muted-foreground transition-transform duration-300",
                    isReferenceOpen && "rotate-180"
                  )} />
                </button>
              </CollapsibleTrigger>
              
              <CollapsibleContent className="mt-2 animate-accordion-down data-[state=closed]:animate-accordion-up">
                <div className="p-3 rounded-lg bg-muted/30 border border-border space-y-3">
                  {/* Reference Images */}
                  <div className="flex gap-2 flex-wrap items-center">
                    {referenceImages.map((img, index) => (
                      <div key={index} className="relative group">
                        <img 
                          src={img} 
                          alt={`Reference ${index + 1}`}
                          className="w-16 h-16 object-cover rounded-lg border border-border"
                        />
                        <button
                          onClick={() => removeReference(index)}
                          className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                    
                    {/* Add button inline */}
                    {referenceImages.length < 5 && (
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        disabled={isLoading}
                        className="w-16 h-16 rounded-lg border-2 border-dashed border-border hover:border-primary/50 flex items-center justify-center text-muted-foreground hover:text-primary transition-colors"
                      >
                        <Upload className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                  
                  {/* Reference Similarity Slider */}
                  <div className="flex items-center gap-3">
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">الالتزام بالريفرنس</span>
                        <span className="text-sm text-primary font-medium">{referenceSimilarity}%</span>
                      </div>
                      <Slider
                        value={[referenceSimilarity]}
                        onValueChange={(v) => setReferenceSimilarity(v[0])}
                        min={0}
                        max={100}
                        step={5}
                        className="w-full"
                      />
                      <p className="text-xs text-muted-foreground">
                        أقل = إبداع أكتر • أعلى = التزام أكتر بالريفرنس
                      </p>
                    </div>
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>
          )}

          <div className="flex gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleAddReference}
              className="hidden"
            />
            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the image you want to create... (e.g., 'A serene mountain landscape at sunset')"
              className="min-h-[80px] resize-none flex-1"
              disabled={isLoading}
            />
          </div>

          <Button 
            onClick={handleGenerate}
            className="w-full ai-gradient"
            disabled={!prompt.trim() || isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Generate Image
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

interface ImageCardProps {
  image: GeneratedImage;
  onDownload: () => void;
  onEnhance: (params: any) => Promise<GeneratedImage | null>;
  isLoading: boolean;
}

function ImageCard({ image, onDownload, onEnhance, isLoading }: ImageCardProps) {
  const [enhanceEnabled, setEnhanceEnabled] = useState(false);
  const [isEnhancing, setIsEnhancing] = useState(false);

  const handleEnhance = async () => {
    if (!enhanceEnabled || isEnhancing || isLoading) return;
    
    setIsEnhancing(true);
    try {
      await onEnhance({
        prompt: `Enhance and improve this image: ${image.prompt}. Make it sharper, more detailed, and higher quality.`,
        model: image.model || 'geminigen/imagen-pro',
        referenceImages: [image.imageUrl],
        quality: 'high',
        referenceSimilarity: 85,
      });
      toast.success('تم تحسين الصورة!');
    } catch (err) {
      toast.error('فشل تحسين الصورة');
    } finally {
      setIsEnhancing(false);
      setEnhanceEnabled(false);
    }
  };

  return (
    <div className="ai-card group overflow-hidden p-0">
      <div className="relative aspect-square overflow-hidden rounded-t-xl">
        <img 
          src={image.imageUrl} 
          alt={image.prompt}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="absolute bottom-3 right-3 flex gap-2">
            <Button 
              size="sm" 
              variant="secondary"
              onClick={onDownload}
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Download
            </Button>
          </div>
        </div>
      </div>
      <div className="p-4 space-y-3">
        <p className="text-sm text-muted-foreground line-clamp-2">{image.prompt}</p>
        
        {/* Enhance Toggle */}
        <div className="flex items-center justify-between p-2 rounded-lg bg-muted/30">
          <div className="flex items-center gap-2">
            <Wand2 className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium">تحسين الصورة</span>
          </div>
          <div className="flex items-center gap-2">
            <Switch
              checked={enhanceEnabled}
              onCheckedChange={setEnhanceEnabled}
              disabled={isEnhancing || isLoading}
            />
            {enhanceEnabled && (
              <Button
                size="sm"
                variant="ghost"
                onClick={handleEnhance}
                disabled={isEnhancing || isLoading}
                className="text-primary"
              >
                {isEnhancing ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  'تطبيق'
                )}
              </Button>
            )}
          </div>
        </div>
        
        <div className="flex items-center justify-between flex-wrap gap-1">
          <p className="text-xs text-muted-foreground/60">
            {new Date(image.timestamp).toLocaleString()}
          </p>
          <div className="flex gap-1">
            {image.size && (
              <span className="text-xs px-2 py-0.5 rounded bg-muted text-muted-foreground">
                {image.size}
              </span>
            )}
            {image.model && (
              <span className="text-xs px-2 py-0.5 rounded bg-muted text-muted-foreground">
                {image.model.split('/').pop()?.replace('-image', '').replace('-preview', '')}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}