import { useState } from 'react';
import { Mic, MicOff, Loader2, Trash2, FileAudio, Copy, Check, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ModelSelector } from './ModelSelector';
import { useAIAudio, Transcription } from '@/hooks/useAIAudio';
import { audioModels } from '@/lib/ai-models';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export function AudioTranscriber() {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedModel, setSelectedModel] = useState(audioModels[0].id);
  const { 
    transcriptions, 
    isLoading, 
    isRecording, 
    error,
    startRecording, 
    recordAndTranscribe,
    transcribe,
    clearTranscriptions 
  } = useAIAudio();

  const handleToggleRecording = async () => {
    if (isRecording) {
      const result = await recordAndTranscribe(selectedModel);
      if (result) {
        toast.success('Audio transcribed successfully!');
      } else if (error) {
        toast.error(error);
      }
    } else {
      await startRecording();
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      toast.error('Please upload an audio file');
      return;
    }

    const result = await transcribe(file, selectedModel);
    if (result) {
      toast.success('Audio transcribed successfully!');
    } else if (error) {
      toast.error(error);
    }

    e.target.value = '';
  };

  const copyToClipboard = async (text: string, id: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedId(id);
    toast.success('Copied to clipboard');
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <ModelSelector
          models={audioModels}
          selectedModel={selectedModel}
          onSelect={setSelectedModel}
        />
        <Button
          variant="ghost"
          size="sm"
          onClick={clearTranscriptions}
          disabled={transcriptions.length === 0}
          className="text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="h-4 w-4 mr-2" />
          Clear
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin">
        {transcriptions.length === 0 && !isLoading ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="ai-gradient w-16 h-16 rounded-2xl flex items-center justify-center mb-4">
              <Mic className="h-8 w-8 text-primary-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Transcribe audio to text</h3>
            <p className="text-muted-foreground max-w-sm">
              Record your voice or upload an audio file to get an accurate transcription using Whisper.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {isLoading && (
              <div className="ai-card flex items-center gap-3">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
                <span className="text-muted-foreground">Processing audio...</span>
              </div>
            )}
            {transcriptions.map((transcription) => (
              <TranscriptionCard
                key={transcription.id}
                transcription={transcription}
                onCopy={() => copyToClipboard(transcription.text, transcription.id)}
                isCopied={copiedId === transcription.id}
              />
            ))}
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="p-4 border-t border-border">
        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            onClick={handleToggleRecording}
            disabled={isLoading}
            className={cn(
              "flex-1",
              isRecording 
                ? "bg-destructive hover:bg-destructive/90" 
                : "ai-gradient"
            )}
          >
            {isRecording ? (
              <>
                <MicOff className="h-4 w-4 mr-2" />
                Stop Recording
              </>
            ) : (
              <>
                <Mic className="h-4 w-4 mr-2" />
                Start Recording
              </>
            )}
          </Button>
          
          <label className="flex-1">
            <input
              type="file"
              accept="audio/*"
              onChange={handleFileUpload}
              className="hidden"
              disabled={isLoading || isRecording}
            />
            <Button
              variant="outline"
              className="w-full"
              disabled={isLoading || isRecording}
              asChild
            >
              <span>
                <Upload className="h-4 w-4 mr-2" />
                Upload Audio
              </span>
            </Button>
          </label>
        </div>
        
        {isRecording && (
          <div className="mt-3 flex items-center justify-center gap-2 text-destructive">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-destructive"></span>
            </span>
            <span className="text-sm font-medium">Recording in progress...</span>
          </div>
        )}
      </div>
    </div>
  );
}

function TranscriptionCard({ 
  transcription, 
  onCopy, 
  isCopied 
}: { 
  transcription: Transcription;
  onCopy: () => void;
  isCopied: boolean;
}) {
  return (
    <div className="ai-card group relative">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <p className="text-sm leading-relaxed">{transcription.text}</p>
          <p className="text-xs text-muted-foreground mt-3">
            {new Date(transcription.timestamp).toLocaleString()}
          </p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onCopy}
          className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          {isCopied ? (
            <Check className="h-4 w-4 text-primary" />
          ) : (
            <Copy className="h-4 w-4" />
          )}
        </Button>
      </div>
    </div>
  );
}
