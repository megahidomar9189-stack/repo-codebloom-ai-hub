import { Video, Sparkles, Loader2, Play, Download, AlertCircle, Clock, Upload, Image, X, Wand2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useState, useRef } from 'react';
import { toast } from 'sonner';
import { useAIVideo, GeneratedVideo } from '@/hooks/useAIVideo';
import { cn } from '@/lib/utils';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

const PROVIDERS = [
  { id: 'sora', name: 'Sora', provider: 'OpenAI', description: 'Cutting-edge text-to-video with stunning realism' },
  { id: 'veo3', name: 'Veo 3', provider: 'Google AI', description: 'Advanced video generation with high quality' },
  { id: 'veo2', name: 'Veo 2', provider: 'Google AI', description: 'Fast and reliable video generation' },
];

const ORIENTATIONS = [
  { id: '16:9', label: 'Landscape', icon: '🖼️' },
  { id: '9:16', label: 'Portrait', icon: '📱' },
];

const RESOLUTIONS = [
  { id: '720p', label: '720p (HD)' },
  { id: '1080p', label: '1080p (Full HD)' },
];

const DURATIONS = [
  { id: 5, label: '5s' },
  { id: 8, label: '8s' },
  { id: 10, label: '10s' },
];

export function VideoGenerator() {
  const [prompt, setPrompt] = useState('');
  const [selectedProvider, setSelectedProvider] = useState(PROVIDERS[0]);
  const [orientation, setOrientation] = useState('16:9');
  const [resolution, setResolution] = useState('720p');
  const [duration, setDuration] = useState(8);
  const [mode, setMode] = useState<'create' | 'extend'>('create');
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  const [lastFrame, setLastFrame] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { videos, isLoading, generateVideo } = useAIVideo();

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (mode === 'create') {
          setReferenceImage(reader.result as string);
        } else {
          setLastFrame(reader.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a prompt');
      return;
    }

    try {
      await generateVideo({
        prompt: prompt.trim(),
        model: selectedProvider.id,
        duration: duration,
        aspectRatio: orientation,
      });
      toast.success('Video generation started!');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to generate video');
    }
  };

  const handleDownload = async (video: GeneratedVideo) => {
    if (!video.videoUrl) return;
    
    try {
      const response = await fetch(video.videoUrl);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `video-${video.id}.mp4`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      toast.error('Failed to download video');
    }
  };

  const selectLastFrameFromVideo = (video: GeneratedVideo) => {
    if (video.videoUrl) {
      setLastFrame(video.videoUrl);
      setMode('extend');
      toast.success('Last frame selected for extension');
    }
  };

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <Video className="h-5 w-5 text-primary" />
          <span className="font-semibold text-lg">AI Video Generator</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto p-6 space-y-6">
          {/* Mode Tabs */}
          <Tabs value={mode} onValueChange={(v) => setMode(v as 'create' | 'extend')}>
            <TabsList className="grid w-full grid-cols-2 max-w-xs">
              <TabsTrigger value="create" className="flex items-center gap-2">
                <Wand2 className="h-4 w-4" />
                Create New
              </TabsTrigger>
              <TabsTrigger value="extend" className="flex items-center gap-2">
                <Play className="h-4 w-4" />
                Extend Video
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Provider Selection */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-muted-foreground">Select Video Generation Provider</label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {PROVIDERS.map((provider) => (
                <button
                  key={provider.id}
                  onClick={() => setSelectedProvider(provider)}
                  className={cn(
                    "p-4 rounded-xl border-2 text-left transition-all",
                    selectedProvider.id === provider.id
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50"
                  )}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold">{provider.name}</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                      {provider.provider}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">{provider.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Reference Image / Last Frame */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-muted-foreground">
              {mode === 'create' ? 'Image Reference (Optional)' : 'Last Frame from Video'}
            </label>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageUpload}
              accept="image/*"
              className="hidden"
            />
            {(mode === 'create' ? referenceImage : lastFrame) ? (
              <div className="relative w-40 h-24 rounded-lg overflow-hidden border border-border">
                <img 
                  src={mode === 'create' ? referenceImage! : lastFrame!} 
                  alt="Reference" 
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => mode === 'create' ? setReferenceImage(null) : setLastFrame(null)}
                  className="absolute top-1 right-1 p-1 rounded-full bg-background/80 hover:bg-background"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ) : (
              <Button
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                className="h-24 w-40 flex flex-col items-center justify-center gap-2 border-dashed"
              >
                {mode === 'create' ? (
                  <>
                    <Image className="h-6 w-6 text-muted-foreground" />
                    <span className="text-xs">Add Image</span>
                  </>
                ) : (
                  <>
                    <Upload className="h-6 w-6 text-muted-foreground" />
                    <span className="text-xs">Select Frame</span>
                  </>
                )}
              </Button>
            )}
            {mode === 'extend' && videos.length > 0 && (
              <div className="mt-2">
                <p className="text-xs text-muted-foreground mb-2">Or select from generated videos:</p>
                <div className="flex gap-2 flex-wrap">
                  {videos.filter(v => v.status === 'completed').slice(0, 4).map(video => (
                    <button
                      key={video.id}
                      onClick={() => selectLastFrameFromVideo(video)}
                      className="w-16 h-10 rounded border border-border overflow-hidden hover:border-primary transition-colors"
                    >
                      <div className="w-full h-full bg-muted flex items-center justify-center">
                        <Play className="h-3 w-3 text-muted-foreground" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Prompt */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-muted-foreground">Prompt</label>
            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={mode === 'create' 
                ? "Describe the video you want to generate with Sora..."
                : "Describe how you want to extend this video..."
              }
              className="min-h-[120px] resize-none"
            />
          </div>

          {/* Settings Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Orientation */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Orientation</label>
              <div className="flex gap-2">
                {ORIENTATIONS.map((o) => (
                  <button
                    key={o.id}
                    onClick={() => setOrientation(o.id)}
                    className={cn(
                      "flex-1 py-2 px-3 rounded-lg border text-sm transition-all flex items-center justify-center gap-2",
                      orientation === o.id
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border hover:border-primary/50"
                    )}
                  >
                    <span>{o.icon}</span>
                    <span>{o.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Resolution */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Resolution</label>
              <div className="flex gap-2">
                {RESOLUTIONS.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => setResolution(r.id)}
                    className={cn(
                      "flex-1 py-2 px-3 rounded-lg border text-sm transition-all",
                      resolution === r.id
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border hover:border-primary/50"
                    )}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Duration */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Duration</label>
              <div className="flex gap-2">
                {DURATIONS.map((d) => (
                  <button
                    key={d.id}
                    onClick={() => setDuration(d.id)}
                    className={cn(
                      "flex-1 py-2 px-3 rounded-lg border text-sm transition-all",
                      duration === d.id
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border hover:border-primary/50"
                    )}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Generate Button */}
          <Button
            onClick={handleGenerate}
            disabled={isLoading || !prompt.trim()}
            className="w-full ai-gradient h-12 text-base"
          >
            {isLoading ? (
              <>
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="h-5 w-5 mr-2" />
                {mode === 'create' ? `Generate with ${selectedProvider.name}` : 'Extend Video'}
              </>
            )}
          </Button>

          {/* Generated Videos */}
          {videos.length > 0 && (
            <div className="space-y-4">
              <h3 className="font-semibold">Generated Videos</h3>
              <div className="grid gap-4">
                {videos.map((video) => (
                  <VideoCard 
                    key={video.id} 
                    video={video} 
                    onDownload={() => handleDownload(video)}
                    onExtend={() => selectLastFrameFromVideo(video)}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function VideoCard({ 
  video, 
  onDownload,
  onExtend 
}: { 
  video: GeneratedVideo; 
  onDownload: () => void;
  onExtend: () => void;
}) {
  return (
    <div className="rounded-xl border border-border overflow-hidden bg-card">
      {/* Video or Status */}
      <div className="aspect-video bg-muted relative">
        {video.status === 'completed' && video.videoUrl ? (
          <video
            src={video.videoUrl}
            controls
            className="w-full h-full object-cover"
          >
            Your browser does not support the video tag.
          </video>
        ) : video.status === 'error' ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-destructive">
            <AlertCircle className="h-12 w-12 mb-2" />
            <p className="text-sm font-medium">Generation Failed</p>
            <p className="text-xs text-muted-foreground mt-1 max-w-xs text-center px-4">{video.error}</p>
          </div>
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="relative">
              <div className="w-16 h-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
              <Play className="h-6 w-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
            </div>
            <p className="text-sm text-muted-foreground mt-4 flex items-center gap-2">
              <Clock className="h-4 w-4" />
              {video.status === 'generating' ? 'Starting generation...' : 'Processing video...'}
            </p>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-4">
        <p className="text-sm line-clamp-2 mb-3">{video.prompt}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className={cn(
              "px-2 py-0.5 rounded-full",
              video.status === 'completed' && "bg-green-500/10 text-green-500",
              video.status === 'error' && "bg-destructive/10 text-destructive",
              (video.status === 'generating' || video.status === 'processing') && "bg-primary/10 text-primary"
            )}>
              {video.status === 'completed' ? 'Ready' : 
               video.status === 'error' ? 'Failed' : 
               video.status === 'generating' ? 'Starting' : 'Processing'}
            </span>
            <span>{video.model}</span>
          </div>
          {video.status === 'completed' && video.videoUrl && (
            <div className="flex gap-2">
              <Button size="sm" variant="ghost" onClick={onExtend}>
                <Play className="h-4 w-4 mr-1" />
                Extend
              </Button>
              <Button size="sm" variant="ghost" onClick={onDownload}>
                <Download className="h-4 w-4 mr-1" />
                Download
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
