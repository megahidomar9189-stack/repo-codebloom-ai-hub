import { Video, Clock, Sparkles, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { toast } from 'sonner';

export function VideoAnalyzer() {
  const [email, setEmail] = useState('');

  const handleNotify = () => {
    if (!email.trim()) {
      toast.error('Please enter your email address');
      return;
    }
    
    // In production, this would call an edge function to store the email
    toast.success('You\'ll be notified when Video AI launches!');
    setEmail('');
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <Video className="h-5 w-5 text-primary" />
          <span className="font-medium">Video AI</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
            Coming Soon
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin">
        <div className="flex flex-col items-center justify-center h-full text-center max-w-md mx-auto">
          {/* Animated icon */}
          <div className="relative mb-8">
            <div className="ai-gradient w-24 h-24 rounded-3xl flex items-center justify-center animate-pulse-slow">
              <Video className="h-12 w-12 text-primary-foreground" />
            </div>
            <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-accent flex items-center justify-center">
              <Clock className="h-4 w-4 text-accent-foreground" />
            </div>
          </div>
          
          <h2 className="text-2xl font-bold mb-3">Video AI is Coming Soon</h2>
          
          <p className="text-muted-foreground mb-8 leading-relaxed">
            We're building powerful video analysis capabilities that will let you 
            analyze, describe, and extract insights from video content.
          </p>

          {/* Features preview */}
          <div className="grid gap-4 w-full mb-8">
            <FeaturePreview 
              icon={Sparkles}
              title="Scene Description"
              description="Get detailed descriptions of what's happening in each scene"
            />
            <FeaturePreview 
              icon={Video}
              title="Content Analysis"
              description="Analyze video content for objects, actions, and context"
            />
          </div>

          {/* Notification signup */}
          <div className="w-full space-y-3">
            <p className="text-sm text-muted-foreground">
              Get notified when Video AI launches
            </p>
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1"
              />
              <Button onClick={handleNotify} className="ai-gradient">
                <Bell className="h-4 w-4 mr-2" />
                Notify Me
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FeaturePreview({ 
  icon: Icon, 
  title, 
  description 
}: { 
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
}) {
  return (
    <div className="flex items-start gap-3 p-4 rounded-xl bg-muted/50 text-left">
      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
        <Icon className="h-5 w-5 text-primary" />
      </div>
      <div>
        <h3 className="font-medium text-sm mb-1">{title}</h3>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}
