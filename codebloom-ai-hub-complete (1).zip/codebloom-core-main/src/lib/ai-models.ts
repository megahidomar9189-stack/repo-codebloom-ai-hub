export interface AIModel {
  id: string;
  name: string;
  description: string;
  category: 'text' | 'image' | 'audio' | 'video';
  provider: string;
  capabilities: string[];
  supportsReferences?: boolean;
}

export const textModels: AIModel[] = [
  {
    id: "openai/gpt-oss-20b",
    name: "GPT-OSS 20B",
    description: "Fast, efficient model for everyday tasks",
    category: "text",
    provider: "Groq",
    capabilities: ["chat", "reasoning", "code", "fast-inference"],
  },
  {
    id: "openai/gpt-oss-120b",
    name: "GPT-OSS 120B",
    description: "Larger model for complex reasoning",
    category: "text",
    provider: "Groq",
    capabilities: ["chat", "reasoning", "code", "analysis"],
  },
];

export const imageModels: AIModel[] = [
  {
    id: "google/gemini-2.0-flash",
    name: "Gemini 2.0 Flash",
    description: "Google Gemini 2.0 Flash - سريع وذكي جداً",
    category: "image",
    provider: "Google",
    capabilities: ["generation", "fast", "high-quality", "multimodal"],
    supportsReferences: false,
  },
];

// Size options for image generation
export const imageSizeOptions = [
  { id: "1024x1024", name: "1:1 Square", description: "1024×1024" },
  { id: "1536x1024", name: "3:2 Landscape", description: "1536×1024" },
  { id: "1024x1536", name: "2:3 Portrait", description: "1024×1536" },
  { id: "1920x1080", name: "16:9 Wide", description: "1920×1080" },
  { id: "1080x1920", name: "9:16 Tall", description: "1080×1920" },
];

// Quality options
export const imageQualityOptions = [
  { id: "low", name: "Draft", description: "Fast preview" },
  { id: "medium", name: "Standard", description: "Balanced quality" },
  { id: "high", name: "HD", description: "Best quality" },
];

export const audioModels: AIModel[] = [
  {
    id: "whisper-large-v3",
    name: "Whisper Large V3",
    description: "High-accuracy audio transcription",
    category: "audio",
    provider: "Groq",
    capabilities: ["transcription", "multilingual"],
  },
  {
    id: "whisper-large-v3-turbo",
    name: "Whisper Large V3 Turbo",
    description: "Fast audio transcription",
    category: "audio",
    provider: "Groq",
    capabilities: ["transcription", "fast"],
  },
];

export const videoModels: AIModel[] = [
  {
    id: "veo3",
    name: "Veo 3",
    description: "Google's latest video generation model",
    category: "video",
    provider: "GeminiGen",
    capabilities: ["generation", "high-quality", "text-to-video"],
  },
  {
    id: "veo2",
    name: "Veo 2",
    description: "Fast and reliable video generation",
    category: "video",
    provider: "GeminiGen",
    capabilities: ["generation", "fast", "text-to-video"],
  },
  {
    id: "sora",
    name: "Sora",
    description: "OpenAI's advanced video generation",
    category: "video",
    provider: "GeminiGen",
    capabilities: ["generation", "cinematic", "text-to-video"],
  },
];

export const getModelsByCategory = (category: AIModel['category']) => {
  switch (category) {
    case 'text': return textModels;
    case 'image': return imageModels;
    case 'audio': return audioModels;
    case 'video': return videoModels;
    default: return [];
  }
};

export const getModelById = (id: string): AIModel | undefined => {
  return [...textModels, ...imageModels, ...audioModels, ...videoModels].find(m => m.id === id);
};
