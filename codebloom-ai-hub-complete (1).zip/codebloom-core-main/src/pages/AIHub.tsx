import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { AIHubSidebar, AITab } from '@/components/ai-hub/AIHubSidebar';
import { ChatInterface } from '@/components/ai-hub/ChatInterface';
import { ImageGenerator } from '@/components/ai-hub/ImageGenerator';
import { AudioTranscriber } from '@/components/ai-hub/AudioTranscriber';
import { VideoGenerator } from '@/components/ai-hub/VideoGenerator';
import { SplashScreen } from '@/components/SplashScreen';

export default function AIHub() {
  const [activeTab, setActiveTab] = useState<AITab>('text');
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [showSplash, setShowSplash] = useState(true);

  const renderContent = () => {
    switch (activeTab) {
      case 'text':
        return <ChatInterface />;
      case 'image':
        return <ImageGenerator />;
      case 'audio':
        return <AudioTranscriber />;
      case 'video':
        return <VideoGenerator />;
      default:
        return <ChatInterface />;
    }
  };

  return (
    <>
      <Helmet>
        <title>CtrlZ - AI Hub</title>
        <meta name="description" content="CtrlZ AI Hub - Developed by Omar Megahid. Access powerful AI capabilities including text generation, image creation, audio transcription, and video analysis." />
      </Helmet>
      
      {showSplash && <SplashScreen onComplete={() => setShowSplash(false)} />}
      
      <div className="flex h-screen w-full bg-background">
        <AIHubSidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          isCollapsed={isCollapsed}
          onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
        />
        <main className="flex-1 overflow-hidden">
          {renderContent()}
        </main>
      </div>
    </>
  );
}
