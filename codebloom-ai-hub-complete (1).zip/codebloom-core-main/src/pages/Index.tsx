import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { 
  MessageSquare, 
  Image, 
  Mic, 
  Video, 
  Sparkles, 
  ArrowRight,
  Zap,
  Shield,
  Globe
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const features = [
  {
    icon: MessageSquare,
    title: 'Text AI',
    description: 'Chat with advanced language models for writing, coding, analysis, and creative tasks.',
  },
  {
    icon: Image,
    title: 'Image AI',
    description: 'Generate stunning images from text descriptions using state-of-the-art models.',
  },
  {
    icon: Mic,
    title: 'Audio AI',
    description: 'Transcribe audio recordings and voice notes with high accuracy.',
  },
  {
    icon: Video,
    title: 'Video AI',
    description: 'Analyze video content and get AI-powered scene descriptions.',
  },
];

const benefits = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Optimized infrastructure for real-time AI responses.',
  },
  {
    icon: Shield,
    title: 'Secure & Private',
    description: 'Your data is encrypted and never stored.',
  },
  {
    icon: Globe,
    title: 'Always Available',
    description: 'Access from anywhere, anytime.',
  },
];

export default function Index() {
  return (
    <>
      <Helmet>
        <title>AI Hub - Unified AI Platform for Text, Image, Audio & Video</title>
        <meta name="description" content="Access powerful AI capabilities including text generation, image creation, audio transcription, and video analysis. Your unified AI platform." />
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          {/* Background gradient */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
          
          <div className="relative container mx-auto px-4 py-24 sm:py-32">
            <div className="text-center max-w-3xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-8 animate-fade-in">
                <Sparkles className="h-4 w-4" />
                <span>Powered by cutting-edge AI</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-6 animate-fade-in">
                Your Unified{' '}
                <span className="ai-gradient-text">AI Hub</span>
              </h1>
              
              <p className="text-lg sm:text-xl text-muted-foreground mb-10 animate-fade-in" style={{ animationDelay: '0.1s' }}>
                Access powerful AI capabilities for text, image, audio, and video — 
                all in one beautiful, easy-to-use platform.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in" style={{ animationDelay: '0.2s' }}>
                <Button asChild size="lg" className="ai-gradient text-lg px-8 h-14">
                  <Link to="/ai-hub">
                    Launch AI Hub
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 sm:py-28 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                Everything you need, in one place
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                From text generation to video analysis, our AI Hub brings together 
                the most powerful AI capabilities.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {features.map((feature, index) => (
                <div 
                  key={feature.title}
                  className="ai-card-interactive animate-fade-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="ai-gradient w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                    <feature.icon className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 sm:py-28">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-3xl sm:text-4xl font-bold mb-6">
                  Built for the modern workflow
                </h2>
                <p className="text-lg text-muted-foreground mb-10">
                  Our AI Hub is designed to seamlessly integrate into your daily tasks, 
                  making AI accessible and practical for everyone.
                </p>
                
                <div className="space-y-6">
                  {benefits.map((benefit) => (
                    <div key={benefit.title} className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <benefit.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">{benefit.title}</h3>
                        <p className="text-sm text-muted-foreground">{benefit.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="relative">
                <div className="ai-card p-8 lg:p-12">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="ai-gradient w-10 h-10 rounded-xl flex items-center justify-center">
                        <Sparkles className="h-5 w-5 text-primary-foreground" />
                      </div>
                      <div>
                        <div className="font-semibold">AI Hub</div>
                        <div className="text-xs text-muted-foreground">Ready to assist</div>
                      </div>
                    </div>
                    
                    <div className="h-px bg-border" />
                    
                    <div className="space-y-3">
                      <div className="bg-muted rounded-lg p-3 text-sm">
                        How can I help you today?
                      </div>
                      <div className="bg-primary/10 rounded-lg p-3 text-sm text-right">
                        Generate an image of a sunset...
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                        <span className="text-sm">Creating your image...</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Decorative elements */}
                <div className="absolute -z-10 top-8 -right-8 w-full h-full ai-gradient rounded-2xl opacity-20 blur-sm" />
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 sm:py-28 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="ai-card text-center py-16 px-8 max-w-3xl mx-auto ai-glow">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                Ready to get started?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">
                Experience the power of unified AI. Start using the AI Hub today.
              </p>
              <Button asChild size="lg" className="ai-gradient text-lg px-8 h-14">
                <Link to="/ai-hub">
                  Launch AI Hub
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div className="ai-gradient w-8 h-8 rounded-lg flex items-center justify-center">
                  <Sparkles className="h-4 w-4 text-primary-foreground" />
                </div>
                <span className="font-semibold">AI Hub</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Powered by cutting-edge AI technology
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}
