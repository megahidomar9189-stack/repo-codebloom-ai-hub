import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Enhanced prompt processing
function enhancePrompt(prompt: string, options: { style?: string; quality?: string }): string {
  const { style, quality } = options;
  
  const qualityGuides: Record<string, string> = {
    low: "Quick draft quality",
    medium: "Good quality, balanced detail",
    high: "Ultra high quality, maximum detail, professional grade, 8K resolution",
  };

  let enhanced = prompt;
  
  if (quality && qualityGuides[quality]) {
    enhanced += `. ${qualityGuides[quality]}`;
  }

  if (style && style !== "default") {
    enhanced += `. Style: ${style}`;
  }

  return enhanced;
}

// Hugging Face API for image generation
async function generateWithHuggingFace(
  prompt: string,
  token: string,
  quality?: string,
  style?: string
): Promise<{ imageUrl?: string; error?: string }> {
  const enhancedPrompt = enhancePrompt(prompt, { quality, style });
  
  console.log("Calling Hugging Face API");
  console.log("Prompt:", enhancedPrompt.substring(0, 100));

  try {
    // Using Hugging Face Inference API with Stable Diffusion via router
    const response = await fetch(
      "https://router.huggingface.co/models/stabilityai/stable-diffusion-3.5-large",
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        method: "POST",
        body: JSON.stringify({
          inputs: enhancedPrompt,
          parameters: {
            negative_prompt: "blurry, low quality, distorted",
            num_inference_steps: quality === "high" ? 50 : quality === "medium" ? 30 : 20,
            guidance_scale: 7.5,
            height: 768,
            width: 768,
          },
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Hugging Face API error:", response.status, errorText);
      
      if (response.status === 429) {
        return { error: "API rate limit exceeded. Please try again in a moment." };
      }
      if (response.status === 401) {
        return { error: "Authentication failed. Invalid token." };
      }
      
      return { error: `API error: ${response.status}` };
    }

    // Response should be image data
    const imageBlob = await response.blob();
    
    if (imageBlob.size === 0) {
      return { error: "Empty response from API" };
    }

    // Convert blob to base64 data URL
    const arrayBuffer = await imageBlob.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64 = btoa(binary);
    const imageUrl = `data:image/png;base64,${base64}`;

    console.log("Image generated successfully");
    return { imageUrl };
  } catch (error) {
    console.error("Error calling Hugging Face:", error);
    return { error: error instanceof Error ? error.message : "Unknown error" };
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { prompt, model, style, size, quality } = await req.json();
    
    if (!prompt) {
      return new Response(JSON.stringify({ error: "Prompt is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log("AI Image generation request");
    console.log("Model:", model);
    console.log("Prompt:", prompt.substring(0, 100) + "...");
    console.log("Style:", style || "default");
    console.log("Size:", size || "768x768");
    console.log("Quality:", quality || "high");

    // Get token from environment
    const token = Deno.env.get("HUGGING_FACE_TOKEN");
    if (!token) {
      throw new Error("HUGGING_FACE_TOKEN is not configured");
    }

    // Generate image using Hugging Face
    const result = await generateWithHuggingFace(
      prompt,
      token,
      quality,
      style
    );

    if (result.error) {
      return new Response(
        JSON.stringify({
          error: result.error,
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    if (!result.imageUrl) {
      return new Response(
        JSON.stringify({
          error: "Failed to generate image. Please try again.",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }
 
    return new Response(
      JSON.stringify({
        imageUrl: result.imageUrl,
        model: "huggingface/stable-diffusion-3.5-large",
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("AI image error:", error);
    
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    
    return new Response(JSON.stringify({ error: errorMessage || "Image generation failed. Please try again." }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
