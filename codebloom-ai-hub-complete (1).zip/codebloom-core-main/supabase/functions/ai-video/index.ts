import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface VideoGenerationRequest {
  prompt: string;
  model?: string;
  duration?: number;
  aspectRatio?: string;
}

// GeminiGen API endpoint
const GEMINIGEN_API_URL = "https://api.geminigen.ai/uapi/v1/generate";

// Map our model IDs to GeminiGen model names
const MODEL_MAP: Record<string, string> = {
  "veo3": "veo-3.0-generate-preview",
  "veo3-fast": "veo-3.0-fast-generate-preview", 
  "veo2": "veo-2.0-generate-preview",
  "sora": "sora-2-turbo",
};

async function generateVideo(params: VideoGenerationRequest, apiKey: string): Promise<{ videoUrl?: string; taskId?: string; status?: string; error?: string }> {
  const { prompt, model = "veo3", duration = 8, aspectRatio = "16:9" } = params;

  const geminiModel = MODEL_MAP[model] || "veo-3.0-generate-preview";
  
  console.log("Generating video with model:", model, "->", geminiModel);
  console.log("Prompt:", prompt.substring(0, 100) + "...");

  try {
    const requestBody = {
      type: "video",
      prompt: prompt,
      model: geminiModel,
      duration: duration,
      aspect_ratio: aspectRatio,
      generate_audio: true,
      enhance_prompt: true,
    };
    
    console.log("Request body:", JSON.stringify(requestBody));

    const response = await fetch(GEMINIGEN_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
      },
      body: JSON.stringify(requestBody),
    });

    const responseText = await response.text();
    console.log("GeminiGen response status:", response.status);
    console.log("GeminiGen response:", responseText.substring(0, 500));

    if (!response.ok) {
      console.error("GeminiGen API error:", response.status, responseText);
      throw new Error(`GeminiGen API error: ${response.status} - ${responseText}`);
    }

    let data;
    try {
      data = JSON.parse(responseText);
    } catch (e) {
      console.error("Failed to parse response as JSON:", e);
      throw new Error("Invalid response from GeminiGen API");
    }

    console.log("Parsed response:", JSON.stringify(data).substring(0, 300));

    // Handle different response formats
    if (data.video_url || data.videoUrl || data.url) {
      return { 
        videoUrl: data.video_url || data.videoUrl || data.url, 
        status: "completed" 
      };
    } else if (data.task_id || data.taskId || data.id) {
      return { 
        taskId: data.task_id || data.taskId || data.id, 
        status: "processing" 
      };
    } else if (data.result?.url || data.result?.video_url) {
      return { 
        videoUrl: data.result.url || data.result.video_url, 
        status: "completed" 
      };
    } else if (data.data?.url || data.data?.video_url) {
      return {
        videoUrl: data.data.url || data.data.video_url,
        status: "completed"
      };
    } else if (data.data?.task_id || data.data?.id) {
      return {
        taskId: data.data.task_id || data.data.id,
        status: "processing"
      };
    }

    // If we got a successful response but can't find video URL, log and return
    console.log("Unknown response format, full data:", JSON.stringify(data));
    return { status: "processing", taskId: data.id || "unknown" };
  } catch (error) {
    console.error("Video generation error:", error);
    throw error;
  }
}

async function checkTaskStatus(taskId: string, apiKey: string): Promise<{ videoUrl?: string; status: string; error?: string }> {
  try {
    // Try different status endpoints
    const statusUrls = [
      `https://api.geminigen.ai/uapi/v1/status/${taskId}`,
      `https://api.geminigen.ai/uapi/v1/task/${taskId}`,
      `https://api.geminigen.ai/uapi/v1/generate/status/${taskId}`,
    ];

    for (const url of statusUrls) {
      try {
        console.log("Checking status at:", url);
        const response = await fetch(url, {
          method: "GET",
          headers: {
            "x-api-key": apiKey,
          },
        });

        if (response.ok) {
          const data = await response.json();
          console.log("Task status response:", JSON.stringify(data));

          const status = data.status || data.state || "processing";
          
          if (status === "completed" || status === "done" || status === "success") {
            const videoUrl = data.video_url || data.videoUrl || data.url || 
                            data.result?.url || data.result?.video_url ||
                            data.data?.url || data.data?.video_url;
            if (videoUrl) {
              return { videoUrl, status: "completed" };
            }
          }

          if (status === "failed" || status === "error") {
            return { 
              status: "failed", 
              error: data.error || data.message || "Generation failed" 
            };
          }

          return { status: status };
        }
      } catch (e) {
        console.log("Status check failed for", url, e);
        continue;
      }
    }

    return { status: "processing" };
  } catch (error) {
    console.error("Check status error:", error);
    throw error;
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("GEMINIGEN_API_KEY");
    if (!apiKey) {
      console.error("GEMINIGEN_API_KEY not configured");
      return new Response(
        JSON.stringify({ error: "Video AI API key not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();
    console.log("Video AI request:", JSON.stringify(body).substring(0, 200));

    // Handle status check
    if (body.action === "status" && body.taskId) {
      const result = await checkTaskStatus(body.taskId, apiKey);
      return new Response(
        JSON.stringify(result),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Handle video generation
    const { prompt, model, duration, aspectRatio } = body;

    if (!prompt) {
      return new Response(
        JSON.stringify({ error: "Prompt is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const result = await generateVideo({ prompt, model, duration, aspectRatio }, apiKey);

    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("AI video error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
